//
//  WebServiceViewController.m
//  FriendsBook
//
//  Created by Nilesh Malviya on 14/07/15.
//  Copyright (c) 2015 KM. All rights reserved.
//

#import "WebServiceViewController.h"

@interface WebServiceViewController ()
@property (nonatomic, strong) NSURLConnection *nsURLConnection;
@property (nonatomic, strong) NSMutableDictionary *responseDictionary;
@property (strong, nonatomic) IBOutlet UITextField *keyTF;
@property (strong, nonatomic) IBOutlet UITextField *otherKeyTF;
@end

@implementation WebServiceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.responseDictionary = [[NSMutableDictionary alloc]init];
}
- (void)viewWillAppear:(BOOL)animated{
    NSString *urlString = @"http://echo.jsontest.com/key/value/otherkey/othervalue";
    NSURL *url = [[NSURL alloc]initWithString:urlString];
    NSURLRequest *urlRequest = [[NSURLRequest alloc]initWithURL:url];
    self.nsURLConnection = [[NSURLConnection alloc]initWithRequest:urlRequest delegate:self];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    self.responseDictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection{
    self.keyTF.text = [self.responseDictionary objectForKey:@"key"];
    self.otherKeyTF.text = [self.responseDictionary objectForKey:@"otherkey"];
}

@end
