//
//  ViewController.m
//  FriendsBook
//
//  Created by Nilesh Malviya on 13/07/15.
//  Copyright (c) 2015 KM. All rights reserved.
//

#import "ViewController.h"
#import "FriendListViewController.h"


@interface ViewController ()
@property (nonatomic, strong)UINavigationController *navController;
@property (nonatomic, strong) FriendListViewController *friendVC;
@property (strong, nonatomic) IBOutlet UITextField *username;
@property (strong, nonatomic) IBOutlet UITextField *password;
- (IBAction)submitButtonPressed:(id)sender;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.friendVC = [[FriendListViewController alloc] initWithNibName:@"FriendListViewController" bundle:nil];
    self.navController = [[UINavigationController alloc]initWithRootViewController:self.friendVC];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)submitButtonPressed:(id)sender {
//    if ([self.username.text isEqualToString:@"nilesh"]) {
//            if ([self.password.text isEqualToString:@"nilesh"]) {
                [self presentViewController:self.navController animated:YES completion:nil];
//            }else {
//                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" message:@"Password is not correct." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
//                [alert show];
//            }
//        }else{
//            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" message:@"Username is not correct." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
//            [alert show];
//        }
}
@end
