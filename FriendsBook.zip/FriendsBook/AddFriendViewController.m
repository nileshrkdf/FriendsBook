//
//  AddFriendViewController.m
//  FriendsBook
//
//  Created by Nilesh Malviya on 13/07/15.
//  Copyright (c) 2015 KM. All rights reserved.
//

#import "AddFriendViewController.h"
#import "CommonUtilityClass.h"
#import "CommonUtilityClass.h"

@interface AddFriendViewController ()
@property (strong, nonatomic) IBOutlet UITextField *friendName;
@property (strong, nonatomic) IBOutlet UITextField *contactNo;
- (IBAction)saveButtonPressed:(id)sender;

@end

@implementation AddFriendViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.frndDetailArray = [[NSMutableArray alloc] init];
    // Do any additional setup after loading the view from its nib.
}
- (void)viewWillAppear:(BOOL)animated{
    if ([self.mode isEqualToString:@"edit"]) {
        self.friendName.text = [self.frndDetailArray objectAtIndex:0];
        self.contactNo.text = [self.frndDetailArray objectAtIndex:1];
    }else{
        self.friendName.text = @"";
        self.contactNo.text = @"";
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)saveButtonPressed:(id)sender {
    if (![self.friendName.text isEqualToString:@""]) {
        if (![self.contactNo.text isEqualToString:@""]) {
            NSArray *frndDetails = [[NSArray alloc] initWithObjects:self.friendName.text,self.contactNo.text, nil];
            if ([self.mode isEqualToString:@"edit"]) {
                for (int i = 0; i < [[CommonUtilityClass sharedManager] frndArray].count; i++) {
                    if ([[[[[CommonUtilityClass sharedManager] frndArray] objectAtIndex:i] objectAtIndex:0] isEqualToString:[self.frndDetailArray objectAtIndex:0]]) {
                        [[[CommonUtilityClass sharedManager] frndArray]  replaceObjectAtIndex:i withObject:frndDetails];
                        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Info" message:@"Your friend details is successfully saved." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
                        [alert show];
                    }
                }
            }else{
                [[[CommonUtilityClass sharedManager] frndArray] addObject:frndDetails];
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Info" message:@"Your friend details is successfully saved." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
                [alert show];
            }
        }else{
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" message:@"Please enter contact no." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
            [alert show];
        }
            
    }else{
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" message:@"Please enter name." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
    }
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0) {
        [self.delegate highlightNewlyAddedRecords];
        [self.navigationController popViewControllerAnimated:YES];
    }
}
@end
