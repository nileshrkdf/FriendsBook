//
//  FriendListViewController.h
//  FriendsBook
//
//  Created by Nilesh Malviya on 13/07/15.
//  Copyright (c) 2015 KM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AddFriendViewController.h"

@interface FriendListViewController : UIViewController <UpdateTableSelection>

@end
